$(document).ready(function() {
	$("<span id = 'username-span'></span>").insertAfter("#username");
	$("<span id = 'password-span'></span>").insertAfter("#password");
	$("<span id = 'email-span'></span>").insertAfter("#email");
	
	$("#username").focus(function () {
		$("#username-span").css("margin-left", "20px");
		$("#username-span").css("display", "inline");
		$("#username-span").removeClass("ok").removeClass("error");
		$("#username-span").addClass("info");
		$("#username-span").text("Please enter a username of your choice. It must contain only alphabets or numbers, or a mixture of both.");
	});
	
	$("#password").focus(function () {
		$("#password-span").css("display", "inline");
		$("#password-span").css("margin-left", "20px");
		$("#password-span").removeClass("ok").removeClass("error");
		$("#password-span").addClass("info");
		$("#password-span").text("Please enter your password. It must be at least 6 characters long.");
	});
	
	$("#email").focus(function () {
		$("#email-span").css("margin-left", "20px");
		$("#email-span").css("display", "inline");
		$("#email-span").removeClass("ok").removeClass("error");
		$("#email-span").addClass("info");
		$("#email-span").text("Please enter your email. It must contain an @ character.");
	});
	
	$("#username").blur(function () {
		if ($(this).val() == '') {
			$("#username-span").css("display", "none");
			}
		else {
			if (/^[a-z0-9]+$/i.test($(this).val())) {
				$("#username-span").css("display", "inline");
				$("#username-span").removeClass("info").removeClass("error");
				$("#username-span").addClass("ok");
				$("#username-span").text("OK");
			}
			else {
				$("#username-span").css("display", "inline");
				$("#username-span").removeClass("info").removeClass("ok");
				$("#username-span").addClass("error");
				$("#username-span").text("error");
			}
		}
	});
	
	$("#password").blur(function () {
		if ($(this).val() == '') {
			$("#password-span").css("display", "none");
			}
		else {
			if ($(this).val().length > 5) {
				$("#password-span").css("display", "inline");
				$("#password-span").removeClass("info").removeClass("error");
				$("#password-span").addClass("ok");
				$("#password-span").text("OK");
			}
			else {
				$("#password-span").css("display", "inline");
				$("#password-span").removeClass("info").removeClass("ok");
				$("#password-span").addClass("error");
				$("#password-span").text("error");
			}
		}
	});
	
	$("#email").blur(function () {
		if ($(this).val() == '') {
			$("#email-span").css("display", "none");
			}
		else {
			if ($(this).val().indexOf("@") > 0) {
				$("#email-span").css("display", "inline");
				$("#email-span").removeClass("info").removeClass("error");
				$("#email-span").addClass("ok");
				$("#email-span").text("OK");
			}
			else {
				$("#email-span").css("display", "inline");
				$("#email-span").removeClass("info").removeClass("ok");
				$("#email-span").addClass("error");
				$("#email-span").text("error");
			}
		}
	});
});
