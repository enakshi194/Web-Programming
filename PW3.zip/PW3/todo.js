
 	$(document).ready(function()
    {

 		$("#new").keypress(function(event){
            if (event.which === 13)
            {
                $("ul").append("<li>" +"<span><i class='fa fa-trash'></i></span>"+ $("#new").val() + "</li>");
            }
 			
 		});
 		//$("#new").focus(function()
        //{
        //    $('#new').css('background', 'blue');
        //});

        $("ul").on("mouseleave", "li", function(){
            $(this).find("span").hide();
        });
        $("ul").on("mouseenter", "li", function(){
            $(this).find("span").show();
        });
		$("ul").on("click", "span", function(){
			$(this).parent().remove();//toggleClass("done");

 		});
        $("h1").on("click", "i", function(){
            $("#new").toggle();

        });
        $("ul").on("click","li",function(){
            $(this).toggleClass("done");
        });



 	});
